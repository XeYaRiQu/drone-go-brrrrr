Chun-Wei, Kong	2021.03.12
email: j2855001@gmail.com

How to Run the file?

Please visit my website:
https://jordan787878.github.io/firstweb/6dofQuadcopter/6dofQuad_Path.html

or the my Youtube channel: Chun-Wei, Kong

6dor Quadcopter Simulation and Control
Part 3 and Part 4.

https://www.youtube.com/watch?v=1WJlS9Xq3ys&list=PLRU9-buIpNwIW-1uUxuRYQAV8oxsstp0s


